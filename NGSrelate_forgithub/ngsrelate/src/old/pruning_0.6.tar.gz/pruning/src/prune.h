
#ifndef _types_h
#define _types_h
#include "types.h"
#endif





class prune{
public:
  fromCres* main_run(toCargs *pars);
};
