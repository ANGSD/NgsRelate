 
prune<-function(data,prune=0.1,LD=c("rsq2","D","D'"),back=50){
  
 
  if(class(data)!="matrix")
    stop("data must be a matrix")
  if(prune>=1|prune<=0)
    stop("prune must be betweeen 0 and 1")
  snp<-dim(data)[2]
  if(back>=snp)
    stop("back must be lower than the number of SNPs")
  LD<-match.arg(LD)

  d<-as.integer(data)
  d[is.na(d)]<-0
  d<-as.integer(d)
  data<-matrix(d,ncol=snp)
  LD_var <- ifelse(LD=="rsq2",TRUE,FALSE)
  res<-.Call(interface,data,prune,as.integer(LD_var),as.numeric(back),PACKAGE="pruning")
  snp<-dim(res$data)[2]
  d<-as.integer(res$data)
  d[d==0]<-NA
  d<-as.integer(d)

  obj<-list()

  obj$pruned_data<-matrix(d,ncol=snp)
  obj$usedSNPs<-  res$usedSnps
  obj$original_data
  obj$LD<-LD_var
  obj$back<-back
  obj$prune_theshold<-prune
  obj$LD_meansure<-LD
  obj$call<-match.call()
  class(obj)<-"pruning"
  return(obj)
}
